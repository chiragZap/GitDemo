//
//  AboutUSViewController.h
//  Music App
//
//  Created by ZAPMAC3 on 23/05/14.
//  Copyright (c) 2014 Zaptech Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUSViewController : UIViewController

- (IBAction)btnBackPressed:(id)sender;

@end
